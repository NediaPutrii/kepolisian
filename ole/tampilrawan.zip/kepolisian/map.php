<!-- 
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA1TwYksj1uQg1V_5yPUZqwqYYtUIvidrY&callback=basemap"></script>
 -->
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="js/jquery.easing.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/grayscale.js"></script>

    <!--Fancybox-->
    <script type="text/javascript" src="fancy/jquery.mousewheel-3.0.6.pack.js"></script> <!-- Sertakan JQuery mousewheel untuk image gallery!-->
    <script type="text/javascript" src="fancy/source/jquery.fancybox.js?v=2.1.5"></script> <!-- Sertakan JQuery fancybox dan cssnya-->
    <link rel="stylesheet" type="text/css" href="fancy/source/jquery.fancybox.css?v=2.1.5" media="screen" />

   <!-- script pencarian -->
  <script type="text/javascript">
      // $(function(){
      //   $('.fancybox').fancybox();
      //   $.ajax({
      //   url: server+'/carikejahatan.php', data: "", dataType: 'json', success: function(rows)
      //     {
      //       for (var i in rows)
      //         {
      //           var row = rows[i];
      //           $('#selectkejahatan').append('<option value="'+row+'">'+row+'</option>');
      //         }
      //     }
      //    });
        $(document).on('change','#selectkejahatan',function()
          {
            $('.fancybox').fancybox();
              $.ajax({
                url: server+'/carikejahatan.php?id_kejahatan='+id_kejahatan+'&nama_kejahatan='+nama_kejahatan+'', data: "", dataType: 'json', success: function(rows)
                    {
                      for (var i in rows)
                      {
                        var row = rows[i];
                        var idjenis=row.id_jenis;
                        var jenis=row.jenis;
                        $('#selectkejahatan').append('<option value="'+id_kejahatan+'">'+nama_kejahatan+'</option>');
                      }
                  }
                });
          });
      });
  </script>


  <script type="text/javascript">
      var infowindow;
      var geomarker;
      var markerarray = [];
      var map;
      var objek;
      var directionsService;
      var directionDisplay;
      var usegeolocation;
      var server='http://localhost:8080/TB/webserver/';
      var markerarraygeo=[];
      var circlearray=[];
      var layernya;

      function initialize() {
            geolocation();
            basemap();
        }
      function basemap() {
          	google.maps.visualRefresh = true;
            map = new google.maps.Map(document.getElementById('map_canvas'), {
                  zoom: 16,
                  center: new google.maps.LatLng(0.5356302, 101.4391664),
                  mapTypeId: google.maps.MapTypeId.satellit
            });
            loadLayer();
        };

      function loadLayer(){
            layernya = new google.maps.Data();
            // layernya.loadGeoJson(server+'layer.php');
            layernya.setMap(mymap);

        }
      function loaddata(results){
        		if(results.features === null)
                 {
                     alert("Data yang dicari tidak ada");
                 }
                 else
                 {
                    for (var i = 0; i < results.features.length; i++) {
                        var data = results.features[i];
                        var coords = data.geometry.coordinates;
                        var id = data.properties.id;
                        var nama = data.properties.nama_obj;
                        var pemilik= data.properties.pemilik;
                        var alamat= data.properties.alamat;
                        var layanan=data.properties.layanan;
                        var jam= data.properties.jam;
                        var no= data.properties.no_telp;
                        var titiktengah = data.properties.center;
                        var latitude = titiktengah.lat;
                        var longitude = titiktengah.lng;
                        var latLng = new google.maps.LatLng(latitude,longitude);
                  		  var gambar=data.properties.image; //menmpilkan informasi pada pencarian
                  		     $('.listdaftar').append('<p><b><a class="fancybox" href="#berita'+id+'"">'+nama+'</a></b></p><p>Travel Mode : <select id="travelmode"><option value="DRIVING">Driving</option><option value="WALKING">Walking</option><option value="BICYCLING">Bicycling</option><option value="TRANSIT">Transit</option></select></p><button id="'+i+'" class="buttongetdirection">Get Direction</button><br><br><div class="panel"></div>');
                  			 $('#berita').append('<div id="berita'+id+'" style="width:600px;display:none;text-align:justify;"><h2><b><center>'+nama+'</b></h2><br><br><center><img src="'+server+'/'+gambar+'" style="width:50%; height:50%"></center><br><br><p style="margin:5px;"><p>Layanan yang Tersedia : '+layanan+'</p><p>Jam Buka - Jam Tutup : '+jam+'</p>  </div>');
                        var iconBase = 'https://maps.google.com/mapfiles/kml/shapes/';
                        var marker = new google.maps.Marker({
                            position: latLng,
                            map: map,
                            animation: google.maps.Animation.DROP,            
                            icon: "img/galon.png",
                            title: nama
                            //shadow: iconBase + 'schools_maps.shadow.png'
                          });

        		            markerarray.push(marker); //menampilkan informasi pada marking
                        
                        var isiinfo="<div style='width:300px; min-height:100px;'><b><h2><center>"+id+". "+nama+"</center></h2></b><center><p>Nama Pemilik : "+pemilik+"</p><img src='"+server+"/"+gambar+"' style='width:50%;'></center><center><br><br><p>Alamat : "+alamat+"</p></center><center><p>Layanan : "+layanan+"</p></center><center><p>Jam Buka - Jam Tutup : "+jam+"</p></center><center><p>No Telpon : "+no+"</p></center></div>";                        createInfoWindow(marker, isiinfo);

                        var nova = new google.maps.Circle({  
                          center: latLng,
                          strokeColor: '#FF0000',
                          fillColor: '#FF0000',
                          map: map,
                          radius: 50
                        });


                      }
                  }

            $('.buttongetdirection').click(function(){
                $("#daftar").prepend('<div id="paneldirection"></div>');
                var k=this.id;
                var titikawal=geomarker.getPosition();
                var titikakhir=markerarray[k].getPosition();
                calcRoute(titikawal,titikakhir);
                clearmarker();
        			  $('.listdaftar').html('');
        		      });
          }

      var infowindow = new google.maps.InfoWindow();
      function createInfoWindow(marker, isiinfo) {
            google.maps.event.addListener(marker, 'click', function() {
                infowindow.setContent(isiinfo);
                infowindow.open(map, this);
              });
        }
        google.maps.event.addDomListener(window, 'load', initialize);

      function calcRoute(start, end) {
          var travelmode = document.getElementById("travelmode").options[document.getElementById("travelmode").selectedIndex].value;
          directionsService = new google.maps.DirectionsService();
          var request = {
                 origin:start,
                 destination:end,
                 travelMode: google.maps.TravelMode[travelmode],
                 unitSystem: google.maps.UnitSystem.METRIC,
                 provideRouteAlternatives: true
            };
          directionsService.route(request, function(response, status) {
                if (status == google.maps.DirectionsStatus.OK) {
                 directionsDisplay.setDirections(response);
                }
            });
          directionsDisplay = new google.maps.DirectionsRenderer({draggable: false});
          directionsDisplay.setMap(map);
        	directionsDisplay.setPanel(document.getElementById('paneldirection'));
        }

      function clearmarkergeo(){
          for (var i = 0; i < markerarraygeo.length; i++) {
               markerarraygeo[i].setMap(null);
            }
          markerarraygeo=[];
        }

      function clearmarker(){
          for (var i = 0; i < markerarray.length; i++) {
                markerarray[i].setMap(null);
            }
          markerarray=[];
        }

      function clearroute(){
          directionsDisplay.setMap(null);
        }


      function geolocation(){
          navigator.geolocation.getCurrentPosition(geolocationSuccess, geolocationError);
        }

      function geolocationSuccess(posisi){
          var pos=new google.maps.LatLng(posisi.coords.latitude,posisi.coords.longitude);
          var image = 'img/swiper.png';
          geomarker = new google.maps.Marker({
                map: map,
                position: pos,
                icon: image,
                animation: google.maps.Animation.DROP
        	  });
          map.panTo(pos);
          infowindow = new google.maps.InfoWindow();
          infowindow.setContent('<b>Posisi Swiper Sekarang<b>');
          infowindow.open(map, geomarker);
          usegeolocation=true;
        }

      function geolocationError(err){
          usegeolocation=false;

        }

  </script>
  <!-- silakan ubah ini -->
  <script type="text/javascript">
  		$(function(){
  			$('#cari').click(function(){
  				$('#paneldirection').html('');
  				clearmarker();
  				$(".listdaftar").html("");
  				var hasil = document.getElementById("selectjenis").value;
  				var script1 = document.createElement('script');
          script1.src = server+'/carikejahatan.php?idjenis='+hasil+'';
  				document.getElementsByTagName('head')[0].appendChild(script1);
  				clearroute();
  				});
  		});

	</script>

<!-- membuat pencarian dan peta -->
    <div class="container">
        <div class="col-md-8 col-lg-offset-2">
        <div class="searchbox" style="text-align: center;">
            <h2>Pilih Kejahatan :</h2>
            <select class="custom-select"  name="selectkejahatan" id="selectkejahatan" class="custom-select" placeholder="Kata kunci" style="color: black;">
                <option>- Tipe -</option>
            </select>

            <button id="cari" class="btn blue" >SEARCH</button>
        </div>
        </div>
    </div>
    <br>
    <div id="berita"></div>

    <div class="col-md-4">
      <div class="control-group">
          <div class="controls">
          <div id="daftar" style="float: left;">
                <div class="listdaftar"></div>
          </div>
          </div>
      </div>
    </div>

    <div class="col-md-8">  
          <div class="control-group" style="float: right;">
          <div id="map_canvas" style="height: 500px; width: 10px;"></div>
          </div>
    </div> 
    
    
    
    