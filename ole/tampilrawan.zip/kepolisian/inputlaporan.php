<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.8.0/css/bulma.min.css">
    
    <script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js"></script>
    <title>Input Laporan</title>
    <style>
        .form
        {
            weight : 400px;
        }
    </style>
</head>

<body > 
    <div classs="container text-center" style="background-color:skyblue;">
        <h1>INPUT LAPORAN KRIMINAL</h1>
    </div>
<form action="input.php" method="post">
    <div class="container" >
        
            <div class="field">
                <label class="label">No Laporan</label>
                <div class="control">
                    <input class="input" type="text" placeholder="" name="nolaporan">
                </div>
            </div>

            <div class="field">
                <label class="label">Tempat Kejadian</label>
                <div class="control">
                    <input class="input" type="text" placeholder="" name="tempatkejadian">
                </div>
            </div>   

            <div class="field">
                <label class="label">Tanggal Kejadian</label>
                <div class="control">
                    <input class="input" type="date" placeholder="" name="tanggalkejadian">
                </div>
            </div>

            <div class="field">
                <label class="label">Penaganan</label>
                <div class="control">
                    <input class="input" type="text" placeholder="" name="penanganan">
                </div>
            </div>    

            <div class="field">
                <label class="label">Status Kejadian</label>
                <div class="control">
                    <input class="input" type="text" placeholder="" name="statuskejadian">
                </div>
            </div>    



                <div class="field is-grouped">
                <div class="control">
                    <button type="submit" class="button is-link">Submit</button>
                </div>
                <div class="control">
                    <button type="reset" class="button is-link is-light">Reset</button>
                </div>
                </div>

    </div>
</form>  
</body>
</html>