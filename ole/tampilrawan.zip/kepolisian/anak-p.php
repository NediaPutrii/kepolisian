<?php 
include "koneksi.php";
"<br>";



$shape = $_POST['polygon'];
$nolaporan=$_POST['nolaporan'];


$query= mysqli_query ($koneksi,"UPDATE laporan SET koordinat = '$shape', SHAPE=GeomFromText('$shape') WHERE laporan.nolaporan='$nolaporan' ") or die(mysqli_error($koneksi));

if ($query){ echo '<center>data berhasil disimpan<a id="click" href="javascript:window.close()"><br><input type="submit" name="submit" value="OK"></a></center>';}
else echo "gagal";
?>
<!-- (koordinat,SHAPE) VALUES('$shape',GeomFromText('$shape'))
UPDATE `laporan` SET `tempatkejadian` = 'rumah kos' WHERE `laporan`.`nolaporan` = '';
UPDATE `laporan` SET `tglkejadian` = '2020-03-12', `penanganan` = 'ndjeqnw' WHERE `laporan`.`nolaporan` = '' -->