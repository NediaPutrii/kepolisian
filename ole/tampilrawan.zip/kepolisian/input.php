<?php 

    include 'koneksi.php';

    $nolaporan = $_POST['nolaporan'];
    $tempatkejadian = $_POST['tempatkejadian'];
    $tanggalkejadian = $_POST['tanggalkejadian'];
    $penanganan = $_POST['penanganan'];
    $statuskejadian = $_POST['statuskejadian'];
   // $shape = $_GET['nilai'];

    $simpan = mysqli_query($koneksi, "INSERT INTO laporan (nolaporan,tempatkejadian,tglkejadian,penanganan,statuskejadian) value ('$nolaporan','$tempatkejadian','$tanggalkejadian','$penanganan','$statuskejadian')");

    echo "<script> location='input_digitasi.php?nolaporan=$nolaporan/'</script>"

?>