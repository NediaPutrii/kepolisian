var solidFuels = [
              	{
            		"2010": "85",
            		"CountryCode": "004",
            		"Country": "Afghanistan"
            	},
            	{
            		"2010": "39",
            		"CountryCode": "008",
            		"Country": "Albania"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "012",
            		"Country": "Algeria"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "020",
            		"Country": "Andorra"
            	},
            	{
            		"2010": "55",
            		"CountryCode": "024",
            		"Country": "Angola"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "028",
            		"Country": "Antigua and Barbuda"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "032",
            		"Country": "Argentina"
            	},
            	{
            		"2010": "19",
            		"CountryCode": "051",
            		"Country": "Armenia"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "036",
            		"Country": "Australia"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "040",
            		"Country": "Austria"
            	},
            	{
            		"2010": "7",
            		"CountryCode": "031",
            		"Country": "Azerbaijan"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "044",
            		"Country": "Bahamas"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "048",
            		"Country": "Bahrain"
            	},
            	{
            		"2010": "91",
            		"CountryCode": "050",
            		"Country": "Bangladesh"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "052",
            		"Country": "Barbados"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "112",
            		"Country": "Belarus"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "056",
            		"Country": "Belgium"
            	},
            	{
            		"2010": "12",
            		"CountryCode": "084",
            		"Country": "Belize"
            	},
            	{
            		"2010": "91",
            		"CountryCode": "204",
            		"Country": "Benin"
            	},
            	{
            		"2010": "",
            		"CountryCode": "060",
            		"Country": "Bermuda"
            	},
            	{
            		"2010": "40",
            		"CountryCode": "064",
            		"Country": "Bhutan"
            	},
            	{
            		"2010": "29",
            		"CountryCode": "068",
            		"Country": "Bolivia"
            	},
            	{
            		"2010": "45",
            		"CountryCode": "070",
            		"Country": "Bosnia and Herzegovina"
            	},
            	{
            		"2010": "37",
            		"CountryCode": "072",
            		"Country": "Botswana"
            	},
            	{
            		"2010": "6",
            		"CountryCode": "076",
            		"Country": "Brazil"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "096",
            		"Country": "Brunei Darussalam"
            	},
            	{
            		"2010": "14",
            		"CountryCode": "100",
            		"Country": "Bulgaria"
            	},
            	{
            		"2010": "92",
            		"CountryCode": "854",
            		"Country": "Burkina Faso"
            	},
            	{
            		"2010": "95",
            		"CountryCode": "108",
            		"Country": "Burundi"
            	},
            	{
            		"2010": "89",
            		"CountryCode": "116",
            		"Country": "Cambodia"
            	},
            	{
            		"2010": "75",
            		"CountryCode": "120",
            		"Country": "Cameroon"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "124",
            		"Country": "Canada"
            	},
            	{
            		"2010": "32",
            		"CountryCode": "132",
            		"Country": "Cape Verde"
            	},
            	{
            		"2010": "",
            		"CountryCode": "136",
            		"Country": "Cayman Islands"
            	},
            	{
            		"2010": "95",
            		"CountryCode": "140",
            		"Country": "Central African Republic"
            	},
            	{
            		"2010": "88",
            		"CountryCode": "148",
            		"Country": "Chad"
            	},
            	{
            		"2010": "",
            		"CountryCode": "830",
            		"Country": "Channel Islands"
            	},
            	{
            		"2010": "6",
            		"CountryCode": "152",
            		"Country": "Chile"
            	},
            	{
            		"2010": "46",
            		"CountryCode": "156",
            		"Country": "China"
            	},
            	{
            		"2010": "14",
            		"CountryCode": "170",
            		"Country": "Colombia"
            	},
            	{
            		"2010": "71",
            		"CountryCode": "174",
            		"Country": "Comoros"
            	},
            	{
            		"2010": "77",
            		"CountryCode": "178",
            		"Country": "Congo"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "184",
            		"Country": "Cook Islands"
            	},
            	{
            		"2010": "6",
            		"CountryCode": "188",
            		"Country": "Costa Rica"
            	},
            	{
            		"2010": "78",
            		"CountryCode": "384",
            		"Country": "Cote d'Ivoire"
            	},
            	{
            		"2010": "8",
            		"CountryCode": "191",
            		"Country": "Croatia"
            	},
            	{
            		"2010": "9",
            		"CountryCode": "192",
            		"Country": "Cuba"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "196",
            		"Country": "Cyprus"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "203",
            		"Country": "Czech Republic"
            	},
            	{
            		"2010": "93",
            		"CountryCode": "180",
            		"Country": "Democratic Republic of the Congo"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "208",
            		"Country": "Denmark"
            	},
            	{
            		"2010": "13",
            		"CountryCode": "262",
            		"Country": "Djibouti"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "212",
            		"Country": "Dominica"
            	},
            	{
            		"2010": "7",
            		"CountryCode": "214",
            		"Country": "Dominican Republic"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "218",
            		"Country": "Ecuador"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "818",
            		"Country": "Egypt"
            	},
            	{
            		"2010": "22",
            		"CountryCode": "222",
            		"Country": "El Salvador"
            	},
            	{
            		"2010": "51",
            		"CountryCode": "226",
            		"Country": "Equatorial Guinea"
            	},
            	{
            		"2010": "60",
            		"CountryCode": "232",
            		"Country": "Eritrea"
            	},
            	{
            		"2010": "11",
            		"CountryCode": "233",
            		"Country": "Estonia"
            	},
            	{
            		"2010": "95",
            		"CountryCode": "231",
            		"Country": "Ethiopia"
            	},
            	{
            		"2010": "37",
            		"CountryCode": "242",
            		"Country": "Fiji"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "246",
            		"Country": "Finland"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "250",
            		"Country": "France"
            	},
            	{
            		"2010": "26",
            		"CountryCode": "266",
            		"Country": "Gabon"
            	},
            	{
            		"2010": "91",
            		"CountryCode": "270",
            		"Country": "Gambia"
            	},
            	{
            		"2010": "46",
            		"CountryCode": "268",
            		"Country": "Georgia"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "276",
            		"Country": "Germany"
            	},
            	{
            		"2010": "84",
            		"CountryCode": "288",
            		"Country": "Ghana"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "300",
            		"Country": "Greece"
            	},
            	{
            		"2010": "",
            		"CountryCode": "304",
            		"Country": "Greenland"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "308",
            		"Country": "Grenada"
            	},
            	{
            		"2010": "57",
            		"CountryCode": "320",
            		"Country": "Guatemala"
            	},
            	{
            		"2010": "95",
            		"CountryCode": "324",
            		"Country": "Guinea"
            	},
            	{
            		"2010": "95",
            		"CountryCode": "624",
            		"Country": "Guinea-Bissau"
            	},
            	{
            		"2010": "7",
            		"CountryCode": "328",
            		"Country": "Guyana"
            	},
            	{
            		"2010": "91",
            		"CountryCode": "332",
            		"Country": "Haiti"
            	},
            	{
            		"2010": "51",
            		"CountryCode": "340",
            		"Country": "Honduras"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "348",
            		"Country": "Hungary"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "352",
            		"Country": "Iceland"
            	},
            	{
            		"2010": "58",
            		"CountryCode": "356",
            		"Country": "India"
            	},
            	{
            		"2010": "55",
            		"CountryCode": "360",
            		"Country": "Indonesia"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "364",
            		"Country": "Iran (Islamic Republic of)"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "368",
            		"Country": "Iraq"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "372",
            		"Country": "Ireland"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "376",
            		"Country": "Israel"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "380",
            		"Country": "Italy"
            	},
            	{
            		"2010": "11",
            		"CountryCode": "388",
            		"Country": "Jamaica"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "392",
            		"Country": "Japan"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "400",
            		"Country": "Jordan"
            	},
            	{
            		"2010": "9",
            		"CountryCode": "398",
            		"Country": "Kazakhstan"
            	},
            	{
            		"2010": "80",
            		"CountryCode": "404",
            		"Country": "Kenya"
            	},
            	{
            		"2010": "80",
            		"CountryCode": "296",
            		"Country": "Kiribati"
            	},
            	{
            		"2010": "91",
            		"CountryCode": "408",
            		"Country": "Korea, Democratic People's Republic of"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "410",
            		"Country": "Korea, Republic of"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "414",
            		"Country": "Kuwait"
            	},
            	{
            		"2010": "34",
            		"CountryCode": "417",
            		"Country": "Kyrgyzstan"
            	},
            	{
            		"2010": "95",
            		"CountryCode": "418",
            		"Country": "Lao People's Democratic Republic"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "428",
            		"Country": "Latvia"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "422",
            		"Country": "Lebanon"
            	},
            	{
            		"2010": "61",
            		"CountryCode": "426",
            		"Country": "Lesotho"
            	},
            	{
            		"2010": "95",
            		"CountryCode": "430",
            		"Country": "Liberia"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "434",
            		"Country": "Libyan Arab Jamahiriya"
            	},
            	{
            		"2010": "",
            		"CountryCode": "438",
            		"Country": "Liechtenstein"
            	},
            	{
            		"2010": "21",
            		"CountryCode": "440",
            		"Country": "Lithuania"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "442",
            		"Country": "Luxembourg"
            	},
            	{
            		"2010": "95",
            		"CountryCode": "450",
            		"Country": "Madagascar"
            	},
            	{
            		"2010": "95",
            		"CountryCode": "454",
            		"Country": "Malawi"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "458",
            		"Country": "Malaysia"
            	},
            	{
            		"2010": "8",
            		"CountryCode": "462",
            		"Country": "Maldives"
            	},
            	{
            		"2010": "95",
            		"CountryCode": "466",
            		"Country": "Mali"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "470",
            		"Country": "Malta"
            	},
            	{
            		"2010": "32",
            		"CountryCode": "584",
            		"Country": "Marshall Islands"
            	},
            	{
            		"2010": "58",
            		"CountryCode": "478",
            		"Country": "Mauritania"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "480",
            		"Country": "Mauritius"
            	},
            	{
            		"2010": "14",
            		"CountryCode": "484",
            		"Country": "Mexico"
            	},
            	{
            		"2010": "41",
            		"CountryCode": "583",
            		"Country": "Micronesia, Federated States of"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "492",
            		"Country": "Monaco"
            	},
            	{
            		"2010": "72",
            		"CountryCode": "496",
            		"Country": "Mongolia"
            	},
            	{
            		"2010": "28",
            		"CountryCode": "499",
            		"Country": "Montenegro"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "504",
            		"Country": "Morocco"
            	},
            	{
            		"2010": "95",
            		"CountryCode": "508",
            		"Country": "Mozambique"
            	},
            	{
            		"2010": "92",
            		"CountryCode": "104",
            		"Country": "Myanmar"
            	},
            	{
            		"2010": "55",
            		"CountryCode": "516",
            		"Country": "Namibia"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "520",
            		"Country": "Nauru"
            	},
            	{
            		"2010": "82",
            		"CountryCode": "524",
            		"Country": "Nepal"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "528",
            		"Country": "Netherlands"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "554",
            		"Country": "New Zealand"
            	},
            	{
            		"2010": "54",
            		"CountryCode": "558",
            		"Country": "Nicaragua"
            	},
            	{
            		"2010": "95",
            		"CountryCode": "562",
            		"Country": "Niger"
            	},
            	{
            		"2010": "74",
            		"CountryCode": "566",
            		"Country": "Nigeria"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "570",
            		"Country": "Niue"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "578",
            		"Country": "Norway"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "512",
            		"Country": "Oman"
            	},
            	{
            		"2010": "64",
            		"CountryCode": "586",
            		"Country": "Pakistan"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "585",
            		"Country": "Palau"
            	},
            	{
            		"2010": "18",
            		"CountryCode": "591",
            		"Country": "Panama"
            	},
            	{
            		"2010": "73",
            		"CountryCode": "598",
            		"Country": "Papua New Guinea"
            	},
            	{
            		"2010": "49",
            		"CountryCode": "600",
            		"Country": "Paraguay"
            	},
            	{
            		"2010": "36",
            		"CountryCode": "604",
            		"Country": "Peru"
            	},
            	{
            		"2010": "50",
            		"CountryCode": "608",
            		"Country": "Philippines"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "616",
            		"Country": "Poland"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "620",
            		"Country": "Portugal"
            	},
            	{
            		"2010": "",
            		"CountryCode": "630",
            		"Country": "Puerto Rico"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "634",
            		"Country": "Qatar"
            	},
            	{
            		"2010": "11",
            		"CountryCode": "498",
            		"Country": "Republic of Moldova"
            	},
            	{
            		"2010": "17",
            		"CountryCode": "642",
            		"Country": "Romania"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "643",
            		"Country": "Russian Federation"
            	},
            	{
            		"2010": "95",
            		"CountryCode": "646",
            		"Country": "Rwanda"
            	},
            	{
            		"2010": "56",
            		"CountryCode": "659",
            		"Country": "Saint Kitts and Nevis"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "662",
            		"Country": "Saint Lucia"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "670",
            		"Country": "Saint Vincent and the Grenadines"
            	},
            	{
            		"2010": "53",
            		"CountryCode": "882",
            		"Country": "Samoa"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "674",
            		"Country": "San Marino"
            	},
            	{
            		"2010": "71",
            		"CountryCode": "678",
            		"Country": "Sao Tome and Principe"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "682",
            		"Country": "Saudi Arabia"
            	},
            	{
            		"2010": "51",
            		"CountryCode": "686",
            		"Country": "Senegal"
            	},
            	{
            		"2010": "32",
            		"CountryCode": "688",
            		"Country": "Serbia"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "690",
            		"Country": "Seychelles"
            	},
            	{
            		"2010": "95",
            		"CountryCode": "694",
            		"Country": "Sierra Leone"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "702",
            		"Country": "Singapore"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "703",
            		"Country": "Slovakia"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "705",
            		"Country": "Slovenia"
            	},
            	{
            		"2010": "90",
            		"CountryCode": "090",
            		"Country": "Solomon Islands"
            	},
            	{
            		"2010": "95",
            		"CountryCode": "706",
            		"Country": "Somalia"
            	},
            	{
            		"2010": "15",
            		"CountryCode": "710",
            		"Country": "South Africa"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "724",
            		"Country": "Spain"
            	},
            	{
            		"2010": "75",
            		"CountryCode": "144",
            		"Country": "Sri Lanka"
            	},
            	{
            		"2010": "79",
            		"CountryCode": "736",
            		"Country": "Sudan"
            	},
            	{
            		"2010": "12",
            		"CountryCode": "740",
            		"Country": "Suriname"
            	},
            	{
            		"2010": "55",
            		"CountryCode": "748",
            		"Country": "Swaziland"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "752",
            		"Country": "Sweden"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "756",
            		"Country": "Switzerland"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "760",
            		"Country": "Syrian Arab Republic"
            	},
            	{
            		"2010": "34",
            		"CountryCode": "762",
            		"Country": "Tajikistan"
            	},
            	{
            		"2010": "26",
            		"CountryCode": "764",
            		"Country": "Thailand"
            	},
            	{
            		"2010": "33",
            		"CountryCode": "807",
            		"Country": "The former Yugoslav Republic of Macedonia"
            	},
            	{
            		"2010": "92",
            		"CountryCode": "626",
            		"Country": "Timor-Leste"
            	},
            	{
            		"2010": "94",
            		"CountryCode": "768",
            		"Country": "Togo"
            	},
            	{
            		"2010": "",
            		"CountryCode": "772",
            		"Country": "Tokelau"
            	},
            	{
            		"2010": "43",
            		"CountryCode": "776",
            		"Country": "Tonga"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "780",
            		"Country": "Trinidad and Tobago"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "788",
            		"Country": "Tunisia"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "792",
            		"Country": "Turkey"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "795",
            		"Country": "Turkmenistan"
            	},
            	{
            		"2010": "19",
            		"CountryCode": "798",
            		"Country": "Tuvalu"
            	},
            	{
            		"2010": "95",
            		"CountryCode": "800",
            		"Country": "Uganda"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "804",
            		"Country": "Ukraine"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "784",
            		"Country": "United Arab Emirates"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "826",
            		"Country": "United Kingdom"
            	},
            	{
            		"2010": "94",
            		"CountryCode": "834",
            		"Country": "United Republic of Tanzania"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "840",
            		"Country": "United States"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "858",
            		"Country": "Uruguay"
            	},
            	{
            		"2010": "11",
            		"CountryCode": "860",
            		"Country": "Uzbekistan"
            	},
            	{
            		"2010": "84",
            		"CountryCode": "548",
            		"Country": "Vanuatu"
            	},
            	{
            		"2010": "5",
            		"CountryCode": "862",
            		"Country": "Venezuela"
            	},
            	{
            		"2010": "56",
            		"CountryCode": "704",
            		"Country": "Viet Nam"
            	},
            	{
            		"2010": "33",
            		"CountryCode": "887",
            		"Country": "Yemen"
            	},
            	{
            		"2010": "83",
            		"CountryCode": "894",
            		"Country": "Zambia"
            	},
            	{
            		"2010": "66",
            		"CountryCode": "716",
            		"Country": "Zimbabwe"
            	}
            ];