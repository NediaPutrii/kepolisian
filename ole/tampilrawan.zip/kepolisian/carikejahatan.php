<?php
include ('koenksi.php');
					
// $tipe=$_GET["tipe"];
$sql=mysqli_query("select id_jenis,jenis from tipe,jenis where jenis.id_tipe=tipe.id_tipe AND tipe='$tipe'");
$dataarray=array();
			
while($row = pg_fetch_array($sql))
  {
	 $id_kejahatan=$row['id_kejahatan'];
	 $nama_kejahatan=$row['nama_kejahatan'];
	 $dataarray[]=array('id_kejahatan'=>$dataidjenis,'nama_kejahatan'=>$nama_kejahatan);
  }
  echo json_encode ($dataarray);
					  
?>